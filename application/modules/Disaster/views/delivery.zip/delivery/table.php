<div class="wraper">      
        
    <div class="row">
        
        <div class="col-lg-9 col-sm-12">

            <h1><strong>Agent Delivery</strong></h1>

        </div>

    </div>

    <div class="col-lg-12 container contant-wraper">    

        <h3>

            <small><a href="<?php echo site_url("Disaster/addAgentDelivery");?>" class="btn btn-primary" style="width: 100px;">Add</a></small>
            <span class="confirm-div" style="float:right; color:green;"></span>

        </h3>

        <table class="table table-bordered table-hover">

            <thead>

                <tr>
                
                    <th>Sl No</th>
                    <th>Date</th>
                    <th>District</th>
                    <th>Agent</th>
                    <th>Order No</th>
                    <th>Bill No</th>
                    <th>Quantity(M.T)</th>
                    <th>Amount</th>
                    <th>Option</th>
                    
                </tr>

            </thead>

            <tbody>

                <?php
                    foreach($data as $key)
                    {
                ?>
                    <tr>

                        <td><?php echo $key->sl_no; ?></td>
                        <td><?php echo $key->del_dt; ?></td>
                        <td><?php echo $key->district_name; ?></td>
                        <td><?php echo $key->agent; ?></td>
                        <td><?php echo $key->order_no; ?></td>
                        <td><?php echo $key->bill_no; ?></td>
                        <td><?php echo $key->qty; ?></td>
                        <td><?php echo $key->amount; ?></td>
                        
                        <td><a href="<?php //echo site_url('Disaster/editDistPointEntry/'.$key->point_no.'/'); ?>"><i class="fa fa-edit fa-fw fa-2x"></i></a></td>

                    </tr> 

                <?php
                    }
                ?>

            </tbody>

        </table>

    </div>

</div>