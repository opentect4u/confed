
<div class="wraper">      

    <div class="col-md-7 container form-wraper">

        <form role="form" name="agent_delForm" method="POST" id="form" action="<?php echo site_url("Disaster/entryAgentDelivery");?>" onsubmit="return validate()" >
        
            <div class="form-header">
            
                <h4>Add New Delivery</h4>
            
            </div>

                <div class="form-group row">

                    <label for="del_dt" class="col-sm-2 col-form-label">Date:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <input type="date" name="del_dt" class="form-control required" id="del_dt" />
            
                    </div>

                </div>

                <div class="form-group row">

                    <label for="dist_cd" class="col-sm-2 col-form-label">District:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <select type="text" name="dist_cd" class="form-control required" id="dist_cd" >
                            <option value= "">Select District</option>
                            <?php
                                foreach($dist_data as $key)
                                { 
                                ?>
                                    <option value="<?php echo ($key->district_code); ?>"><?php echo ($key->district_name); ?></option>
                            <?php
                                }
                                ?>

                        </select>

                    </div>

                    <label for="point_no" class="col-sm-2 col-form-label">Agent:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <select class="form-control" name="point_no" id="point_no" required >
                                        
                            <option value= "">Select Agent</option>                                              
                                    
                        </select>
                    
                    </div>

                </div>

                <div class="form-group row">

                    <label for="order_no" class="col-sm-2 col-form-label">W.O No:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <input type="Text" name="order_no" class="form-control required" id="order_no" />
            
                    </div>

                    <label for="qty_bal" class="col-sm-2 col-form-label">Alloted Balance(M.T):</label>

                    <div class="col-sm-4">

                        <input type="Text" name="qty_bal" class="form-control required" id="qty_bal" readonly/>
            
                    </div>


                </div>


                <div class="form-group row">

                    <label for="order_no" class="col-sm-2 col-form-label">Bill No:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <input type="Text" name="bill_no" class="form-control required" id="bill_no" />
            
                    </div>

                    <label for="rate" class="col-sm-2 col-form-label">Rate:<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <input type="Text" name="rate" class="form-control required" id="rate" />
            
                    </div>


                </div>

                <div class="form-group row">

                    <label for="qty" class="col-sm-2 col-form-label">Quantity (M.T):<font color="red">*</font></label>

                    <div class="col-sm-4">

                        <input type="Text" name="qty" class="form-control required" id="qty" />
            
                    </div>

                    <label for="amount" class="col-sm-2 col-form-label">Amount:</label>

                    <div class="col-sm-4">

                        <input type="Text" name="amount" class="form-control required" id="amount" readonly />
            
                    </div>


                </div>


            <div class="form-group row">

                <div class="col-sm-10">

                    <input type="submit" class="btn btn-info" value="Save" />

                </div>

            </div>

        </form>

    </div>

</div>






<!-- To get Agents of as per District -->

<script>

    $(document).ready(function(){

        var i = 1;

        $('#dist_cd').change(function(){

            $.get( 

                '<?php echo site_url("Disaster/js_agent");?>',
                { 

                    dist_cd: $(this).val()

                }

            ).done(function(data){

                var string = '<option value="">Select</option>';

                $.each(JSON.parse(data), function( index, value ) {

                    string += '<option value="' + value.point_no + '">' + value.agent + '- '+ (value.sdo) +'</option>'

                });

                
                $('#point_no').html(string);

            });

        });


    });

</script>

<!-- To get total undelivered alloted balance of a agent as per WO No & Dist_cd -->

<script>

    $(document).ready(function(){

        var i = 2;

        $('#order_no').change(function(){

            $.get( 

                '<?php echo site_url("Disaster/js_agent_allotQtyBal");?>',
                { 

                    order_no: $(this).val(),
                    dist_cd : $('#dist_cd').val(),
                    point_no: $('#point_no').val()
                    
                }

            )

            .done(function(data){

                console.log(data);
                var tot_allot_bal = JSON.parse(data);

                $('#qty_bal').val(tot_allot_bal);

            });

        });

    });

</script>


<script>

    $(document).ready(function(){

        $('#qty').change(function(){

            //console.log(1111);
            
            qty = $(this).val();
            rate = $('#rate').val();
            
            var amount = rate*qty;
            $("#amount").val(amount);

        });

    });

</script> 



<!-- To Validate/ Check whather distributed tot_qnt exceeds distict allot_qty   -->

<script>

        var delAmount    =   document.forms["agent_delForm"]["qty"];
        var qtyBal       =   document.forms["agent_delForm"]["qty_bal"];

    function validate()
    {
        if(delAmount.value > qtyBal.value)
        {
            
            qty.style.border = "1px solid red";
            
            return false;
        }
        else
        {
            return true;
        }

    }

</script>
