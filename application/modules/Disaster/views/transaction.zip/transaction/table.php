<div class="wraper">      
        
    <div class="row">
        
        <div class="col-lg-9 col-sm-12">

            <h1><strong>Work Order</strong></h1>

        </div>

    </div>

    <div class="col-lg-12 container contant-wraper">    

        <h3>

            <small><a href="<?php echo site_url("Disaster/addAgentDistribution");?>" class="btn btn-primary" style="width: 100px;">Add</a></small>
            <span class="confirm-div" style="float:right; color:green;"></span>

        </h3>

        <table class="table table-bordered table-hover">

            <thead>

                <tr>
                
                    <th>Sl No</th>
                    <th>District</th>                    
                    <th>SDO</th>
                    <th>BDO</th>
                    <th>Agent</th>
                    <th>Order No</th>
                    <th>Quantity</th>
                    <th>Option</th>
                    
                </tr>

            </thead>

            <tbody>

                <?php
                    foreach($data as $key)
                    {
                ?>
                    <tr>

                        <td><?php echo $key->sl_no; ?></td>
                        <td><?php echo $key->district_name; ?></td> 
                        <td><?php echo $key->sdo; ?></td>                        
                        <td><?php echo $key->bdo; ?></td>
                        <td><?php echo $key->agent; ?></td>
                        <td><?php echo $key->order_no; ?></td>
                        <td><?php echo $key->allot_qty; ?></td>
                        
                        <td><a href="<?php echo site_url('Disaster/editAgentDistribution/'.$key->point_no.'/'.$key->sl_no.' '); ?>"><i class="fa fa-edit fa-fw fa-2x"></i></a></td>

                    </tr> 

                <?php
                    }
                ?>

            </tbody>

        </table>

    </div>

</div>